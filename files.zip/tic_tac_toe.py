import sys

def print_board(board):
    print("\n")
    for row in board:
        print(" | ".join(row))
        print("-" * 9)

def check_win(board, player):
    # Check rows, columns and diagonals
    for i in range(3):
        if all(s == player for s in board[i]):  # Rows
            return True
        if all(board[j][i] == player for j in range(3)):  # Columns
            return True
    if all(board[i][i] == player for i in range(3)):  # Main diagonal
        return True
    if all(board[i][2 - i] == player for i in range(3)):  # Anti-diagonal
        return True
    return False

def check_draw(board):
    return all(cell in ['X', 'O'] for row in board for cell in row)

def main():
    board = [["1", "2", "3"],
             ["4", "5", "6"],
             ["7", "8", "9"]]
    players = ["X", "O"]
    turn = 0

    while True:
        print_board(board)
        player = players[turn % 2]
        move = input(f"Player {player}, enter your move (1-9): ")
        try:
            move = int(move) - 1
            row, col = divmod(move, 3)
            if board[row][col] in ['X', 'O']:
                print("Cell already taken, try again!")
                continue
            board[row][col] = player
        except (ValueError, IndexError):
            print("Invalid move, try again!")
            continue

        if check_win(board, player):
            print_board(board)
            print(f"Player {player} wins!")
            break
        if check_draw(board):
            print_board(board)
            print("It's a draw!")
            break
        turn += 1

if __name__ == "__main__":
    main()